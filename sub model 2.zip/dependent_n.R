# install.packages("R2WinBUGS")
library(R2WinBUGS)

# WinBugs location checks
options(bugs.directory = "C:\\Users\\saraa\\OneDrive\\Documents\\WinBugs\\winbugs14_full_patched\\WinBUGS14")
dir.exists(getOption("bugs.directory"))
file.exists(file.path(getOption("bugs.directory"), "WinBUGS14.exe"))

workdir = "C:/WinBUGS_work" #set working directory
if (!dir.exists(workdir)) dir.create(workdir, recursive = TRUE)

#definitions for functions

summ = function(x) c( #takes a numeric vector and returns the usual one-line summary
  mean   = mean(x),
  sd     = sd(x),
  `2.5%` = unname(quantile(x, 0.025)),
  `50%`  = median(x),
  `97.5%`= unname(quantile(x, 0.975))
)

printFit = function(fit, label = "") { #just makes a readable table of summaries for data
  post = fit$sims.list
  tab = rbind(
    n1 = summ(post$n1),
    n2 = summ(post$n2),
    FN = summ(post$FN),
    FP = summ(post$FP)
  )
  tab = round(as.data.frame(tab), 3)
  cat("label:", label)
  print(tab)
  if (!is.null(fit$DIC)) cat("DIC:", round(fit$DIC, 2))
}

printBUGS = function(fit){
  keep = c("p1","p2","n1","n2","FN","FP")
  print(round(fit$summary[keep, c("mean","sd","2.5%","50%","97.5%")], 3))
}

show_bugs_log = function(path = file.path(workdir,"log.txt"), n = 120){
  if (file.exists(path)) cat(paste(tail(readLines(path, warn = FALSE), n), collapse = "\n"))
  else cat("No log.txt found at:", path, "\n")
}


#observed counts from table 2 study

TP = 71 #true positive
TN = 80 #true negative
N  = 182 #total size of study
N1 = as.integer(N - 1) #truncates prior at 1..N-1

#priors

# sensitivity: p1 ~ Beta(a1, b1)
a1 = 1
b1 = 1
# This gives us a Uni(0,1) prior because it doesn't favor any value in [0,1]
# (i.e. neither sensitivity or specificity is stronger than the data) and it is
# conjugate to binomial for dbin for T1 and T2

#specificity: p2 ~ Beta(a2, b2)
a2 = 1
b2 = 1

# for p3 ~ Beta(a3, b3) (NegBin prior on n1)
a3 = 1
b3 = 1

r3 = 3  # For negative-binomial: E[X] = r(1-p)/p   and Var(X) = r(1-p)/p^2
# note: increasing r narrows distribution, decreasing it makes it more heavy-tailed

# Poisson prior parameter
shape = 1
rate  = 1

#BUGS models
writingBugs = function(priorType = c("dcat","poisson","negbin_N1","negbin_TP"),
                        file = "modelContingency.txt"){
  priorType = match.arg(priorType)
  common = '
  model{
    # Likelihood
    TP ~ dbin(p1, n1)
    TN ~ dbin(p2, n2)
    n2 = N - n1

    # Priors
    p1 ~ dbeta(a1, b1)
    p2 ~ dbeta(a2, b2)
  '
  priorBlock = switch(priorType,
                       "dcat" = '
      # n1 ~ dcat(1..N-1) with equal probability 1/N1
      for (i in 1:N1) {
        pi[i] = 1.0 / N1
      }
      n1 ~ dcat(pi[])
    ',
                       "poisson" = '
      # n1 ~ Poisson with truncation
      n1 ~ dpois(lambda) I(1, N1)
      lambda ~ dgamma(shape, rate)
    ',
                       "negbin_N1" = '
      # n1 ~ NegBin with truncation I(1, N1)
      n1 ~ dnegbin(p3, r3) I(1, N1)
      p3 ~ dbeta(a3, b3)
    ',
                       "negbin_TP" = '
      # n1 ~ NegBin truncated to I(TP, N)
      n1 ~ dnegbin(p3, r3) I(TP, N)
      p3 ~ dbeta(a3, b3)
    '
  )
  tail = '
    # Derived
    FN = n1 - TP
    FP = n2 - TN
  }'
  cat(paste0(common, priorBlock, tail), file = file)
  invisible(file)
}

runModel = function(priorType = c("dcat","poisson","negbin_N1","negbin_TP"),
                     n_iter = 20000, n_burnin = 5000, n_thin = 5, n_chains = 3,
                     workdir = getwd(), bugs_dir = getOption("bugs.directory"),
                     debug_flag = FALSE) {
  priorType = match.arg(priorType)
  
  #fresh workdir files for each run (for winBugs issue)
  unlink(file.path(workdir, c("coda","data.txt","inits1.txt","inits2.txt","inits3.txt",
                              "log.txt","script.txt")), recursive = TRUE)
  
  #write model to workdir
  modelFileName = paste0("model_", priorType, ".txt")
  modelFilePath = file.path(workdir, modelFileName)
  writingBugs(priorType, modelFilePath)
  
  dat = switch(priorType,
                "dcat" = list(
                  N = as.integer(N), N1 = as.integer(N1),
                  TP = as.integer(TP), TN = as.integer(TN),
                  a1 = a1, b1 = b1, a2 = a2, b2 = b2
                ),
                "poisson" = list(
                  N = as.integer(N), N1 = as.integer(N1),
                  TP = as.integer(TP), TN = as.integer(TN),
                  a1 = a1, b1 = b1, a2 = a2, b2 = b2,
                  shape = shape, rate = rate
                ),
                "negbin_N1" = list(
                  N = as.integer(N), N1 = as.integer(N1),
                  TP = as.integer(TP), TN = as.integer(TN),
                  a1 = a1, b1 = b1, a2 = a2, b2 = b2,
                  a3 = a3, b3 = b3, r3 = as.integer(r3)
                ),
                "negbin_TP" = list(
                  N = as.integer(N),                # =- keep N (used in I(TP, N))
                  TP = as.integer(TP), TN = as.integer(TN),
                  a1 = a1, b1 = b1, a2 = a2, b2 = b2,
                  a3 = a3, b3 = b3, r3 = as.integer(r3)
                  # NOTE: do NOT pass N1 here; it's not used in this model
                )
  )
  
  
  # safe initial n1 inside support + likelihood constraints
  make_inits = function(){
    if (priorType == "negbin_TP") {
      LB = max( as.integer(TP), 1L )
      UB = as.integer(N)#I(TP, N)
    } else {
      LB = max( as.integer(TP), 1L )
      UB = as.integer(N1)#I(1, N1)
    }
    UB = min(UB, as.integer(N - TN)) #ensures n2 = N - n1 >= TN
    
    #choose the lowest feasible value to avoid binomial mismatch at init
    n1_start = max(LB, min(UB, LB))
    if (!is.finite(n1_start)) n1_start = max(1L, as.integer(N1))
    
    base = list(
      p1 = rbeta(1, a1, b1),
      p2 = rbeta(1, a2, b2),
      n1 = as.integer(n1_start)
    )
    if (priorType == "poisson") base$lambda = max(1e-3, rgamma(1, shape = shape, rate = rate))
    if (priorType %in% c("negbin_N1","negbin_TP")) base$p3 = min(max(rbeta(1, a3, b3), 1e-6), 1-1e-6)
    base
  }
  
  params = c("p1","p2","n1","n2","FN","FP")
  if (priorType %in% c("negbin_N1","negbin_TP")) params = c(params, "p3")
  if (priorType == "poisson")                    params = c(params, "lambda")
  
  fit = try(bugs(
    data = dat,
    inits = list(make_inits(), make_inits(), make_inits()),
    parameters.to.save = params,
    model.file = modelFilePath,
    n.chains = n_chains,
    n.iter = n_iter,
    n.burnin = n_burnin,
    n.thin = n_thin,
    DIC = FALSE,                
    bugs.directory = bugs_dir,
    working.directory = workdir,
    debug = debug_flag
  ), silent = TRUE)
  
  if (inherits(fit, "try-error")) {
    cat("\n--- BUGS LOG tail (", priorType, ") ---\n", sep = "")
    if (file.exists(file.path(workdir,"log.txt"))) {
      cat(paste(tail(readLines(file.path(workdir,"log.txt"), warn = FALSE), 120), collapse = "\n"))
    } else {
      cat("log.txt not found\n")
    }
    stop("WinBUGS run failed for prior '", priorType, "'. See log above.", call. = FALSE)
  }
  
  fit
}

fit_dcat = runModel("dcat", workdir = workdir, debug_flag = FALSE)
printFit(fit_dcat, "dcat  (Uniform 1..N-1)") #check
fit_pois       = runModel("poisson", workdir = workdir, debug_flag = FALSE)
fit_negbin_N1  = runModel("negbin_N1",workdir = workdir, debug_flag = FALSE)
fit_negbin_TP  = runModel("negbin_TP",workdir = workdir, debug_flag = FALSE)

printFit(fit_pois, "Poisson I(1,N-1)")
printFit(fit_negbin_N1,"NegBin I(1,N-1)")
printFit(fit_negbin_TP,"NegBin I(TP,N)")

mean_row = function(fit){
  c(n1 = mean(fit$sims.list$n1),
    n2 = mean(fit$sims.list$n2),
    FN = mean(fit$sims.list$FN),
    FP = mean(fit$sims.list$FP))
}

compare = rbind(
  dcat        = mean_row(fit_dcat),
  poisson     = mean_row(fit_pois),
  negbin_1N1  = mean_row(fit_negbin_N1),
  negbin_TP_N = mean_row(fit_negbin_TP)
)
print(round(as.data.frame(compare), 2))

cat("Feasible n1 (data-implied): [", max(1, TP), ",", N - TN, "]\n")

report_fit = fit_negbin_TP   
point_estimates = function(fit, rule = c("median","mean","map"), round_int = TRUE) {
  rule = match.arg(rule)
  s = fit$sims.list
  need = c("n1","n2","FN","FP")
  if (!all(need %in% names(s))) stop("Posterior draws missing: ", 
                                     paste(setdiff(need, names(s)), collapse=", "))
  get1 = function(x) {
    if (rule == "mean")   return(mean(x))
    if (rule == "median") return(median(x))
    tb = table(x)
    as.numeric(names(tb))[which.max(tb)]
  }
  est = vapply(need, function(v) get1(s[[v]]), numeric(1))
  if (round_int) est = round(est)  
  out = data.frame(estimate = c(est, N = N), row.names = c(need, "N"))
  out
}

one_number = point_estimates(report_fit, rule = "median", round_int = TRUE)
print(one_number)

# --- pick which prior to report (use one of: fit_dcat, fit_pois, fit_negbin_N1, fit_negbin_TP)
report_fit = fit_negbin_TP   # change if you want a different prior

# --- one-number + 95% CI for n1, n2, FN, FP, N ---
ci_and_point = function(fit, vars = c("n1","n2","FN","FP"),
                         point = c("median","mean","map"),
                         round_int = TRUE) {
  point = match.arg(point)
  s = fit$sims.list
  get_point = function(x){
    if (point == "mean")   return(mean(x))
    if (point == "median") return(median(x))
    tb = table(x); as.numeric(names(tb))[which.max(tb)]  # MAP for integer counts
  }
  out = lapply(vars, function(v){
    x = s[[v]]
    c(point = get_point(x),
      lo95  = unname(quantile(x, 0.025)),
      hi95  = unname(quantile(x, 0.975)))
  })
  tab = as.data.frame(do.call(rbind, out))
  rownames(tab) = vars
  if (round_int) tab[,] = round(tab)
  # N is known from data; CI is degenerate at N
  tab = rbind(tab, N = c(point = N, lo95 = N, hi95 = N))
  tab
}

# choose "median" (robust) or "mean" (squared-error optimal), or "map"
res = ci_and_point(report_fit, point = "median", round_int = TRUE)
print(res)


