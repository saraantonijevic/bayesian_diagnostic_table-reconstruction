library(R2WinBUGS)

#winBugs paths
options(bugs.directory = "C:\\Users\\saraa\\OneDrive\\Documents\\WinBugs\\winbugs14_full_patched\\WinBUGS14")
wd <- "C:/WinBUGS_work"; if (!dir.exists(wd)) dir.create(wd, recursive = TRUE)
set.seed(123)

#observed data
TP <- 71L #true positives
FP <- 28L #false positives
n1 <- 99L #positives total

#priors
# Poisson–Gamma for NegBin sizes
#lambda1 ~ Gamma(1,0.1)
a1 <- 1
b1 <- 0.1  

#lambda2 ~ Gamma(2,1)
a2 <- 2
b2 <- 1     

# Accuracy
# p1 ~ Beta(2,1) (sensitivity)
alpha1 <- 2
beta1  <- 1   

#q ~ Beta(2,5)(false-positive rate)
alpha2 <- 2
beta2  <- 5  

# NegBin probabilities

# pstar1 ~ Beta(1,1)   for M
alphastar1 <- 1
betastar1  <- 1

# pstar2 ~ Beta(1,60)  for n2
alphastar2 <- 1
betastar2  <- 60   

#truncation (WinBUGS needs both bounds)
U_M  <- max(1e4, TP + 1000)
U_N2 <- max(1e4, FP + 1000)

#winBugs model
modfile <- file.path(wd, "single_model_nb_poisgamma_trunc.txt")
writeLines(c(
  "model{",
  "  p1 ~ dbeta(alpha1, beta1)",
  "  q  ~ dbeta(alpha2, beta2)",
  "",
  "  lambda1 ~ dgamma(a1, b1)",
  "  r10 ~ dpois(lambda1)",
  "  r1  <- r10 + 1",
  "  pstar1 ~ dbeta(alphastar1, betastar1)",
  "  M ~ dnegbin(pstar1, r1) I(TP, U_M)",
  "",
  "  lambda2 ~ dgamma(a2, b2)",
  "  r20 ~ dpois(lambda2)",
  "  r2  <- r20 + 1",
  "  pstar2 ~ dbeta(alphastar2, betastar2)",
  "  n2 ~ dnegbin(pstar2, r2) I(FP, U_N2)",
  "",
  "  TP ~ dbin(p1, M)",
  "  FP ~ dbin(q,  n2)",
  "",
  "  FN <- M  - TP",
  "  TN <- n2 - FP",
  "  Ntot <- n1 + n2",
  "}"
), modfile, useBytes = TRUE)

#data to send to bugs
dat <- list(
  TP=TP, FP=FP, n1=as.integer(n1),
  a1=a1, b1=b1, a2=a2, b2=b2,
  alpha1=alpha1, beta1=beta1,
  alpha2=alpha2, beta2=beta2,
  alphastar1=alphastar1, betastar1=betastar1,
  alphastar2=alphastar2, betastar2=betastar2,
  U_M=as.integer(U_M), U_N2=as.integer(U_N2)
)

make_inits <- function(){
  list(
    p1 = rbeta(1, alpha1, beta1),
    q  = rbeta(1, alpha2, beta2),
    pstar1 = rbeta(1, alphastar1, betastar1),
    pstar2 = rbeta(1, alphastar2, betastar2),
    lambda1 = rgamma(1, a1, b1),
    lambda2 = rgamma(1, a2, b2),
    r10 = as.integer(rpois(1, 10)),
    r20 = as.integer(rpois(1, 10)),
    M  = as.integer(max(TP, TP + rnbinom(1, size = 5, prob = 0.5))),  # within [TP, U_M]
    n2 = as.integer(max(FP, FP + rnbinom(1, size = 5, prob = 0.5)))   # within [FP, U_N2]
  )
}

#variables to run and estimate
keep <- c("p1","q","M","n2","FN","TN","Ntot",
          "pstar1","pstar2","r1","r2","r10","r20","lambda1","lambda2")

fit <- bugs(
  data = dat,
  inits = list(make_inits(), make_inits(), make_inits()),
  parameters.to.save = keep,
  model.file = modfile,
  n.chains = 3, n.iter = 8000, n.burnin = 2000, n.thin = 1,
  DIC = FALSE,
  bugs.directory = getOption("bugs.directory"),
  working.directory = wd,
  debug = FALSE, clearWD = FALSE
)

print(fit)

#summaries
qs <- function(z) c(mean=mean(z), sd=sd(z),
                    `2.5%`=unname(quantile(z,.025)),
                    `50%`=median(z),
                    `97.5%`=unname(quantile(z,.975)))
post <- fit$sims.list
tab <- rbind(
  FN    = qs(post$FN),
  TN    = qs(post$TN),
  M     = qs(post$M),
  n2    = qs(post$n2),
  Ntot  = qs(post$Ntot),
  sens  = qs(post$p1),
  FPR   = qs(post$q),
  pstar1= qs(post$pstar1),
  pstar2= qs(post$pstar2),
  r1    = qs(post$r1),
  r2    = qs(post$r2)
)
print(as.data.frame(tab))
