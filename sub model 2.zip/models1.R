library(R2WinBUGS)

#WinBugs paths and directory
options(bugs.directory = "C:\\Users\\saraa\\OneDrive\\Documents\\WinBugs\\winbugs14_full_patched\\WinBUGS14")
wd <- "C:/WinBUGS_work"
if (!dir.exists(wd)) dir.create(wd, recursive = TRUE)

set.seed(123)

##data
TP <- 71L
TN <- 80L

## priors
a1 <- 1; b1 <- 1
a2 <- 1; b2 <- 1
aeta1 <- 1e-3; beta1 <- 1e-3
aeta2 <- 1e-3; beta2 <- 1e-3

#model
modfile <- file.path(wd, "model_unknownN_poisson.txt")
writeLines(
  c(
    "model{",
    "  q1 <- 1 - p1",
    "  q2 <- 1 - p2",
    "  rateTP <- eta1 * p1",
    "  rateFN <- eta1 * q1",
    "  rateTN <- eta2 * p2",
    "  rateFP <- eta2 * q2",
    "  TP ~ dpois(rateTP)",
    "  FN ~ dpois(rateFN)",
    "  TN ~ dpois(rateTN)",
    "  FP ~ dpois(rateFP)",
    "  n1 <- TP + FN",
    "  n2 <- TN + FP",
    "  N  <- n1 + n2",
    "  p1 ~ dbeta(a1, b1)",
    "  p2 ~ dbeta(a2, b2)",
    "  eta1 ~ dgamma(aeta1, beta1)",
    "  eta2 ~ dgamma(aeta2, beta2)",
    "}"
  ),
  con = modfile,
  useBytes = TRUE
)

## BUGS inputs
dat <- list(
  TP = as.integer(TP),
  TN = as.integer(TN),
  a1 = a1, b1 = b1,
  a2 = a2, b2 = b2,
  aeta1 = aeta1, beta1 = beta1,
  aeta2 = aeta2, beta2 = beta2
)

init_fun <- function() list(
  p1 = rbeta(1, a1, b1),
  p2 = rbeta(1, a2, b2),
  eta1 = max(1e-3, TP / 0.5),
  eta2 = max(1e-3, TN / 0.5),
  FN = max(1L, TP %/% 3),
  FP = max(1L, TN %/% 3)
)

pars <- c("p1","p2","eta1","eta2","FN","FP","n1","n2","N")

## run
fit <- bugs(
  data = dat,
  inits = list(init_fun(), init_fun(), init_fun()),
  parameters.to.save = pars,
  model.file = modfile,
  n.chains = 3,
  n.iter = 30000,
  n.burnin = 10000,
  n.thin = 5,
  DIC = TRUE,
  bugs.directory = getOption("bugs.directory"),
  working.directory = wd,
  debug = FALSE
)

## summary table
qs <- function(z) c(mean = mean(z), sd = sd(z),
                    `2.5%` = unname(quantile(z, .025)),
                    `50%`  = median(z),
                    `97.5%`= unname(quantile(z, .975)))

post <- fit$sims.list
tab <- rbind(
  n1 = qs(post$n1),
  n2 = qs(post$n2),
  FN = qs(post$FN),
  FP = qs(post$FP),
  N  = qs(post$N)
)

print(round(as.data.frame(tab), 3))
